package edu.uwi.sta.comp3275project;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

import edu.uwi.sta.comp3275project.models.DBHelper;
import edu.uwi.sta.comp3275project.models.RollContract;
import edu.uwi.sta.comp3275project.adapters.DBItemAdapter;
import edu.uwi.sta.comp3275project.models.studentProvider;


public class viewAttendance extends AppCompatActivity {

    ListView lv;
    private ArrayAdapter adapter;
    ArrayList<studentProvider> attendance = new ArrayList<>();
    Context context = this;
    String order = RollContract.RollEntry.STUDENT_ID + " ASC ";

    final String[] Columns = new String[]{//database column names
             RollContract.RollEntry.STUDENT_ID,RollContract.RollEntry.COURSE_ID,
             RollContract.RollEntry.COURSE,RollContract.RollEntry.TIME,
            RollContract.RollEntry.ATTENDED


    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_attendance);
        setTitle("Attendance Register");
        lv = (ListView)findViewById(R.id.l_view);
        setUpAdapter();

        (new Thread(new Runnable() {
            @Override
            public void run() {
                // Code to extract information from database
                final SQLiteDatabase db = (new DBHelper(getApplicationContext())).getReadableDatabase(); // create database object, get database, assign usage to readable to prevent locks and assign it to SQL Database db
                // the database will execute the query based on options we specify and store in the Cursor
                Cursor res = db.query(RollContract.RollEntry.TABLE_NAME, Columns, null, null, null, null, order);
                while (res.moveToNext()) {
                    // Retrieve the values from the database putting it in a student provider called attendance
                    final String id = res.getString(res.getColumnIndex(RollContract.RollEntry.STUDENT_ID));
                    final String courseId = res.getString(res.getColumnIndex(RollContract.RollEntry.COURSE_ID));
                    final String Course = res.getString(res.getColumnIndex(RollContract.RollEntry.COURSE));
                    final String Time = res.getString(res.getColumnIndex(RollContract.RollEntry.TIME));
                    final String Attended = res.getString(res.getColumnIndex(RollContract.RollEntry.ATTENDED));


                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            // update the UI

                            studentProvider roll = new studentProvider(id,courseId,Course,Time,Attended);
                            attendance.add(roll);
                            lv.post(new Runnable() {
                                @Override
                                public void run() {
                                    //Notify the adapter that the list changed listview will be redrawn
                                    adapter.notifyDataSetChanged();
                                }
                            });

                        }
                    });
                    db.close();
                }
            }
        })).start();
    }

    protected void setUpAdapter(){
        adapter = new DBItemAdapter(this,attendance);
        lv.setAdapter(adapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) { // create actionbar buttons
        MenuInflater menuInflater = getMenuInflater(); // use of the MenuInflater object method getMenuInflater() assigned to variable menuInflater
        menuInflater.inflate(R.menu.my_menu, menu);//inflate menu
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {// method switch used for if different buttons were clicked on the ActionBar Menu
        switch(item.getItemId()){

            case R.id.search_id:
                AlertDialog.Builder builder;

                builder = new AlertDialog.Builder(viewAttendance.this); // dialog box with list user chosing one then takes you to another dialog box
                builder.setTitle("Choose a search Method")
                        .setItems(R.array.types, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                AlertDialog.Builder build = new AlertDialog.Builder(context);
                                if (which == 0){
                                    build.setTitle("Please enter an id to search");
// Set up the input
                                    final EditText input = new EditText(context);
// Specify the type of input expected; this, for example, sets the input as a password, and will mask the text
                                    input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_CLASS_TEXT);
                                    build.setView(input);

// Set up the buttons
                                    build.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            String text = input.getText().toString();
                                            if (text.length()<=1){
                                                Toast.makeText(viewAttendance.this,"Please enter a valid id to search",Toast.LENGTH_LONG).show();
                                            }
                                            else {

                                                Intent i = new Intent(viewAttendance.this, ResultStudentId.class);
                                                Bundle bundle = new Bundle();
                                                bundle.putString("id", text); //place the position of the selected item
                                                i.putExtras(bundle); // put bundles in Intent i
                                                startActivity(i); //start resultStudentId activity
                                            }

                                        }
                                    });
                                    build.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.cancel();
                                        }
                                    });

                                    build.show();

                                }

                                else if (which == 1){
                                    build.setTitle("Please enter an Course to search");
// Set up the input
                                    final EditText input = new EditText(context);
// Specify the type of input expected; this, for example, sets the input as a password, and will mask the text
                                    input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_CLASS_TEXT);
                                    build.setView(input);

// Set up the buttons
                                    build.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            String text = input.getText().toString();
                                            if (text.length()<=1){
                                                Toast.makeText(viewAttendance.this,"Please enter a valid course to search",Toast.LENGTH_LONG).show();
                                            }
                                            else {

                                                Intent i = new Intent(viewAttendance.this, ResultCourse.class);
                                                Bundle bundle = new Bundle();
                                                bundle.putString("course", text); //place the position of the selected item
                                                i.putExtras(bundle);
                                                startActivity(i);// start ResultCourse activity
                                            }

                                        }
                                    });
                                    build.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.cancel();
                                        }
                                    });

                                    build.show();


                                }

                                else
                                {
                                    Toast.makeText(context,"Item not on list", Toast.LENGTH_SHORT).show();
                                }


                            }
                        })
                        .create()
                        .show(); // used to show dialog


                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
