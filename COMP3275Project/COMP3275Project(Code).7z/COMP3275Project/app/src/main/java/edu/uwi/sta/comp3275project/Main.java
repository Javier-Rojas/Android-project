package edu.uwi.sta.comp3275project;

import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import org.w3c.dom.Text;

import java.util.Map;

//Kishan Lutchman (812003797) & Javier Rojas (812003809)

public class Main extends AppCompatActivity {
    private Button btnAdmin;
    private String user,pass;
    private final Context context = this;
    private static String username="",password="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Acc Roll Welcome Screen");
        setUpUi();
        setUpClickListeners();

    }

    protected void setUpUi(){
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        btnAdmin=(Button)findViewById(R.id.admin);
    }

    protected void setUpClickListeners(){
        btnAdmin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LayoutInflater li = LayoutInflater.from(context);
                View loginView = li.inflate(R.layout.login, null);
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setView(loginView);
                if(username.isEmpty()&& password.isEmpty()){
                    username= "admin";
                    password= "admin";
                }
                final EditText userInputName = (EditText) loginView.findViewById(R.id.userInputName);// receives the Users Username input attempt
                final EditText userInputPass = (EditText) loginView.findViewById(R.id.userInputPass);//receives the Users Password input attempt

                builder.setCancelable(false);
                builder.setPositiveButton("Submit",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                user = userInputName.getText().toString();//stores user input in string for comparison with stores username
                                pass = userInputPass.getText().toString();//stores user input in a string for comparison with stored password
                                if (user.equalsIgnoreCase(username) && pass.equalsIgnoreCase(password)) {// password for the administrator access is User:admin , Pass:admin
                                    Intent intent = new Intent(getApplicationContext(), admin.class);
                                    startActivity(intent);
                                } else {
                                    Toast.makeText(getApplicationContext(), "Incorrect Password , Please Try Again!", Toast.LENGTH_LONG).show();// displays when an incorrect password is entered
                                }
                            }
                        }).setNegativeButton("Cancel",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        });
                AlertDialog alertD = builder.create();
                alertD.show();
            }
        });
    }

    public void Guest(View v){ // guest menu requires no authentication
        Intent intent = new Intent(getApplicationContext(),guest.class);
        startActivity(intent);
    }

    public static void setUserPass(String user,String pass){ // static function to access username and password and set it to new values
        username=user;
        password=pass;
    }

}
