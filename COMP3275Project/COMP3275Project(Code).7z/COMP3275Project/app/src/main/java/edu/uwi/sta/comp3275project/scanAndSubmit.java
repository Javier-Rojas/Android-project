package edu.uwi.sta.comp3275project;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.ActionBarActivity;
import android.text.InputType;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;

import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import java.util.ArrayList;
import java.util.StringTokenizer;

import edu.uwi.sta.comp3275project.models.DBHelper;
import edu.uwi.sta.comp3275project.models.RollContract;

public class scanAndSubmit extends ActionBarActivity implements View.OnClickListener,AdapterView.OnItemSelectedListener{
    Context context;
    PackageManager packageManager;   // declaration of variables
    TextView  Course,stdID,attended;
    Button btn;
    String userID,course = " ",courseId= " ",attend= " ";
    SQLiteDatabase db;
    long id=-1;
    public static ArrayList<String> courses= new ArrayList<>();




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan_and_submit);
        setTitle("Scan and Submit");
        setUpUI();
        setBaseCourses();


        //Set up flashlight
        context= this;
        packageManager=context.getPackageManager();
        btn=(Button)findViewById(R.id.btn_scan);

        //Text Displays
        stdID=(TextView)findViewById(R.id.bcodetxt);
        attended= (TextView)findViewById(R.id.attend);
        Course =(TextView)findViewById(R.id.code);



        btn.setOnClickListener(this);
        setUpSpinner();




    }

    public void setUpSpinner(){//function to set up spinners
        Spinner spinner = (Spinner) findViewById(R.id.spinner);
// Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item,courses);
// Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);

        Spinner spinner2 = (Spinner) findViewById(R.id.spinner2);
        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(this,R.array.choices,android.R.layout.simple_spinner_item
        );
// Specify the layout to use when the list of choices appears
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        spinner2.setAdapter(adapter1);
        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                attend = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                attend = "No";
            }

        });



    }
    public void setUpUI(){
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder build = new AlertDialog.Builder(context);
                build.setTitle("Please enter a new course to add to the drop down menu");
// Set up the input
                final EditText input = new EditText(context);
// Specify the type of input expected; this, for example, sets the input as a password, and will mask the text
                input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_CLASS_TEXT);
                build.setView(input);

// Set up the buttons
                build.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String text = input.getText().toString().toLowerCase();
                        if(text.contains("-")){
                            courses.add(text);
                        }
                        else{
                            Toast.makeText(context,"You did not enter a valid course",Toast.LENGTH_LONG).show();
                        }

                    }
                });
                build.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                build.show();

            }
        });

    }
    public void setBaseCourses(){
        courses.add(0,"info 1200-intro to information technology");
        courses.add(1,"econ 2020-mathematics for economist");
        courses.add(2,"mgmt 2800-management of business");
        courses.add(3,"info 3410-web technologies");
        courses.add(4,"econ 1001-intro to economics");
        courses.add(5,"agri 4040-agriculture management");
        courses.add(6,"soci 1010-sociology");

    }
    public void onClick (final View v){// onClick for scan&submit button

        if(v.getId()==R.id.btn_scan) {


                if (!packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA)) {
                    Toast.makeText(getApplicationContext(), "Your device has no camera!", Toast.LENGTH_LONG).show();
                } else {

                    IntentIntegrator intIntegrator = new IntentIntegrator(this);
                    intIntegrator.initiateScan();
                }

        }

    }



    public void onActivityResult(int requestCode, int resultCode, Intent intent) {//When barcode scanner receives data

        if(resultCode == RESULT_OK){
        IntentResult intResult=IntentIntegrator.parseActivityResult(requestCode,resultCode,intent);
        if(intResult!=null){



            userID = intResult.getContents();
           SQLiteOpenHelper helper = new DBHelper(this);
            db = helper.getWritableDatabase();

            ContentValues cv = new ContentValues();


            // add a value to the Content Value cv, where the column name is the key
            cv.put(RollContract.RollEntry.STUDENT_ID, userID );
            cv.put(RollContract.RollEntry.COURSE_ID, courseId );
            cv.put(RollContract.RollEntry.COURSE, course );
            cv.put(RollContract.RollEntry.ATTENDED, attend);


            // Insert the new row, returning the primary key value of the new row
             id = db.insert(RollContract.RollEntry.TABLE_NAME, null,cv);





            //set Texts
            stdID.setText("Student ID: " + userID);
            //Course.setText("Course: " + courseId+ " "+course);
            //attended.setText("Attended: "+ attend);




        }
        else{
            Toast.makeText(scanAndSubmit.this,"No data received",Toast.LENGTH_LONG).show();
        }
    }
        else{
            //error message if usesr cancelled the scanning
            Toast.makeText(scanAndSubmit.this,"Error occurred, User stopped the scanner",Toast.LENGTH_LONG).show();
        }
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

@Override
public void onItemSelected(AdapterView<?> parent, View view,
                           int pos, long id) {
    // An item was selected. You can retrieve the selected item using
    // parent.getItemAtPosition(pos)

    String text = parent.getItemAtPosition(pos).toString();

    StringTokenizer st = new StringTokenizer(text, "-");

    final String cId = st.nextToken();
    final String c = st.nextToken();

    courseId = cId;
    course=c;


}

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onResume() { // function called if activity goes into the onResume state
        super.onResume();  // Always call the superclass method first

        if(id != -1){
            Snackbar.make(this.findViewById(android.R.id.content), "Item Successfully inserted", Snackbar.LENGTH_LONG)
                    .setAction("Undo", new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            // undo action to remove recently added id
                            String sql = "DELETE FROM " + RollContract.RollEntry.TABLE_NAME + " WHERE " + RollContract.RollEntry._ID+ "= " + id + ";";
                            db.execSQL(sql);
                            Snackbar.make(v, "Removed successfully", Snackbar.LENGTH_LONG).show();
                        }
                    })
                    .show();
            id = -1;
        }

    }


}
