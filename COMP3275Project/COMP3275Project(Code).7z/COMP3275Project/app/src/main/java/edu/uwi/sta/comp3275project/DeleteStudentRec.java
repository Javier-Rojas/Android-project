package edu.uwi.sta.comp3275project;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import edu.uwi.sta.comp3275project.models.DBHelper;
import edu.uwi.sta.comp3275project.models.RollContract;

public class DeleteStudentRec extends AppCompatActivity {


    private SQLiteOpenHelper helper;
    private SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_student_rec);
        setTitle("Delete Student Record");
    }


    public void deleteStudent(View v){
// function executed when button delete is clicked
        EditText student = (EditText)findViewById(R.id.txt_StudID); // get input from view and set to variables
        EditText course = (EditText)findViewById(R.id.txt_Course);
        String s = student.getText().toString();
        String c = course.getText().toString();
        if(s.length()>1 && c.length()>1) {
            helper = new DBHelper(this);// instance helper created and database to writable
            db = helper.getWritableDatabase();
            // sql string to delete roll records from a particular student for a particular subject
            final String sql = "DELETE FROM " + RollContract.RollEntry.TABLE_NAME + " WHERE " + RollContract.RollEntry.STUDENT_ID + " = " + " '" + s + "' " +
                    " AND " + RollContract.RollEntry.COURSE_ID + " = " + " '" + c + "' " + ";";
            DialogBuilder(sql, db);
        }
        else {

            if(s.length()<=1){
                Snackbar.make(v,"Please enter an Id to delete",Snackbar.LENGTH_SHORT)//Snack bar short duration
                        .setAction("Action",null).show();

            }
            else if(c.length()<=1){
                Snackbar.make(v,"Please enter a course to delete",Snackbar.LENGTH_SHORT)//Snack bar short duration
                        .setAction("Action",null).show();
            }
            else {
                Snackbar.make(v, "No Data entered", Snackbar.LENGTH_SHORT)//Snack bar short duration
                        .setAction("Action", null).show();
            }
        }



    }
    public void deleteAll(View v){ // function executed when button deleteAll is clicked
        helper = new DBHelper(this); // instance helper created and database to writable
        db = helper.getWritableDatabase();
        final String sql = "DELETE FROM " + RollContract.RollEntry.TABLE_NAME + ";"; // delete all sql statement
        DialogBuilder(sql,db);
    }
    protected void DialogBuilder(final String sqlStatement,final SQLiteDatabase db){ // function used to create a dialog box
        AlertDialog.Builder builder;
        builder = new AlertDialog.Builder(DeleteStudentRec.this); //create alert dialog with buttons
        builder.setMessage("!Are you sure you want to Delete Records? It can not be undone!")
                .setTitle("Delete")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() { // positive button
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        db.execSQL(sqlStatement);
                        Toast.makeText(DeleteStudentRec.this, "Records Successfully deleted", Toast.LENGTH_LONG).show();

                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() { // negative button
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(DeleteStudentRec.this, "Records Not deleted", Toast.LENGTH_LONG).show();
                    }
                })
                .create()
                .show(); // used to show dialog
    }
}
