package edu.uwi.sta.comp3275project.models;

import java.util.LinkedList;

/**
 * Created by Kishan on 4/1/2016.
 */

// creation of student provider class
public class studentProvider {

    // declaration of attributes of a student provider object
    private String id;
    private String courseId;
    private String course;
    private String date;
    private String attend;
// constructor
    public studentProvider(String id,String courseId,String course,String time,String attend){
        this.id = id;
        this.courseId = courseId;
        this.course = course;
        this.date = time;
        this.attend = attend;
    }

// getter and setter methods
    public String getID() {
        return id;
    }

    public void setID(String ID) {
        this.id = ID;
    }

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }



    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getAttend() {
        return attend;
    }
    //to string method concatenate all attributes and return a string with all the values
    @Override
    public String toString(){
        return id + " - | " + courseId + "|" + course + "|"+ date + " "+ attend;
    }
// is empty method to check if is empty
    public  boolean isEmpty(){
        if(this.isEmpty()){
            return true;
        }
        else
            return false;
    }


}
