package edu.uwi.sta.comp3275project;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.EditText;

public class ChangeUserPass extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_user_pass);
        setTitle("Change User Password");
    }


    public void changeUserPass(View v) {
        //function upon button press  to change username and password
        EditText et = (EditText) findViewById(R.id.txt_user);//get the values for username,password
        EditText pt = (EditText) findViewById(R.id.txt_pass);
        String user = et.getText().toString();//convert the values for username,password to string and assign
        String pass = pt.getText().toString();

        if ((user.length() > 1) && (pass.length() > 1)) {
            Main.setUserPass(user, pass);
            Snackbar.make(v, "Username and Password successfully Updated", Snackbar.LENGTH_LONG)//snack bar long duration
                    .setAction("undo", new View.OnClickListener() { // set a button to do an action on the snackBar
                        @Override
                        public void onClick(View v) {
                            //undo button to set back username and password to default
                            String user = "admin";
                            String pass = "admin";
                            Main.setUserPass(user, pass);
                        }


                    }).show();
        }
        else{
            Snackbar.make(v,"Please fill out correct values for username and password",Snackbar.LENGTH_SHORT)//Snack bar short duration
                    .setAction("Action",null).show();
        }

    }
}
