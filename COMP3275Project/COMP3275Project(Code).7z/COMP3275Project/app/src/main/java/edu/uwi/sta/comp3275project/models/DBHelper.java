package edu.uwi.sta.comp3275project.models;



import android.content.Context;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


public class DBHelper extends SQLiteOpenHelper{   // created DBHelper class to connect to the database

    private static final String DB_NAME="StudentAttendance"; // name of database declared with version
    private static final int DB_VERSION= 1;


    public DBHelper(Context context){ // use of the constructor from the super class SQLiteOpenHelper
        super(context,DB_NAME,null,DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) { // on FIRST instantiation run code
        db.execSQL(RollContract.CREATE_TABLE); // .execSQL function of db used to run sql code create table from RollContract
       // Log.e("DATABASE OPERATIONS", "Table Created");
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { // code executed if there is an upgrade from an old version to a new one

    }


}
