package edu.uwi.sta.comp3275project.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import edu.uwi.sta.comp3275project.R;
import edu.uwi.sta.comp3275project.models.studentProvider;

/**
 * Created by olusegun on 4/23/2016.
 */

//dbAdapter class to create an item adapter when displaying db items
public class DBItemAdapter extends ArrayAdapter<studentProvider> {
    //constructor
    public DBItemAdapter(Context context, ArrayList<studentProvider> items) {
        super(context, 0, items);
    }

    public View getView(int position, View v, ViewGroup p){
        v = LayoutInflater.from(getContext()).inflate(R.layout.db_layout, null); // assign View v the value of the db layout xml
        // use of student provider getter methods to get values and assign to strings
        studentProvider item = getItem(position);
        String student = item.getID();
        String course = item.getCourse();
        String courseId = item.getCourseId();
        String time = item.getDate();
        String present = item.getAttend();
        //set values to text views items
        ((TextView)v.findViewById(R.id.Student_id)).setText("StudentID: " + student);
        ((TextView)v.findViewById(R.id.courses)).setText("Course: "+courseId +" "+ course);
        ((TextView)v.findViewById(R.id.Date)).setText("Time: " + time);
        ((TextView)v.findViewById(R.id.attend)).setText("Attended: " + present);


        return v;
    }
}
