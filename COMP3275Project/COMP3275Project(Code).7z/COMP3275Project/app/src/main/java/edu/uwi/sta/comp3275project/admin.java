package edu.uwi.sta.comp3275project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.Map;

public class admin extends AppCompatActivity {
    //admin menu items
   private String[] mainTasks = {
            "Attendance Register",
           "Change Login Details",
           "Delete Records",
           "Submit Attendance"};
    //declare variables
    private ArrayAdapter<String> adapter;
    private ListView adminLView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);
        adminLView=(ListView)findViewById(R.id.adminListView);
        setUpAdapter();
        setUpAdapterListeners();
        setTitle("Administrator");
    }

    protected void setUpAdapter(){ // function to set up an adapter on a list
        adapter=new ArrayAdapter<String>(this,android.R.layout.simple_expandable_list_item_1,mainTasks);
        adminLView.setAdapter(adapter);
    }
    protected void setUpAdapterListeners(){//function to set up a listener on a list if an item is clicked
        adminLView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    //go to viewAttendance activity
                    Intent intent = new Intent(getApplicationContext(), viewAttendance.class);
                    startActivity(intent);
                }
                if (position == 1) {
                    //go to ChangeUserPass activity
                    Intent intent = new Intent(getApplicationContext(), ChangeUserPass.class);
                    startActivity(intent);
                }
                if (position == 2) {
                    //go to DeleteStudentRec activity
                    Intent intent = new Intent(getApplicationContext(), DeleteStudentRec.class);
                    startActivity(intent);
                }
                if (position == 3) {
                    //go to scanAndSubmit activity
                    Intent intent = new Intent(getApplicationContext(), scanAndSubmit.class);
                    startActivity(intent);
                }
            }
        });
    }
}
