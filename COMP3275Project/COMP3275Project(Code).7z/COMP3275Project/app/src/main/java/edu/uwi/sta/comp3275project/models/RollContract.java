package edu.uwi.sta.comp3275project.models;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.provider.BaseColumns;
import android.util.Log;



/**
 * Created by olusegun on 4/19/2016.
 */
public class RollContract { // Contract used to provide the framework for the table and attributes to be used in the database
    private static final String TEXT = " TEXT";
    private static final String INT = " INTEGER ";// declaration of types of attributes to be used in the Table

    public static final String CREATE_TABLE=   // Sql statement to create the Attendance table with attributes
            "CREATE TABLE "+ RollEntry.TABLE_NAME+" ("+
            RollEntry._ID+ INT + " PRIMARY KEY AUTOINCREMENT, "+
            RollEntry. STUDENT_ID + TEXT + " NOT NULL, " +
            RollEntry.COURSE_ID + TEXT +" NOT NULL, "+
            RollEntry.COURSE + TEXT+ " NOT NULL, "+
            RollEntry.ATTENDED +TEXT+ " NOT NULL, "+
            RollEntry.TIME +"  TIMESTAMP DEFAULT CURRENT_TIMESTAMP"
            + ");";

    public static abstract class RollEntry implements BaseColumns{ // provides the table and column names used in the database
        public static final String TABLE_NAME = "attendance";
        public static final String  _ID="id";
        public static final String  STUDENT_ID="student";
        public static final String  ATTENDED="attended";
        public static final String  TIME="dateAdded";
        public static final String  COURSE_ID="courseId";
        public static final String  COURSE="courseName";


    }


}
