package edu.uwi.sta.comp3275project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.Map;

public class guest extends AppCompatActivity {
    private String[] mainTasks = {"Submit Attendance"};
    private ArrayAdapter<String> adapter;
    private ListView mainLView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guest);
        mainLView=(ListView)findViewById(R.id.mainLview);
        setUpAdapter();
        setUpAdapterListeners();
        setTitle("Guest");
    }

    protected void setUpAdapter(){//set adapter
        adapter=new ArrayAdapter<String>(this,android.R.layout.simple_expandable_list_item_1,mainTasks);
        mainLView.setAdapter(adapter);
    }

    protected void setUpAdapterListeners(){ //set adapter listener
        mainLView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    Intent intent = new Intent(getApplicationContext(), scanAndSubmit.class);
                    startActivity(intent);
                }
            }
        });
    }
}
