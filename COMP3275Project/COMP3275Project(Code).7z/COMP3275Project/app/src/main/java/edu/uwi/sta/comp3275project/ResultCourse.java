package edu.uwi.sta.comp3275project;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

import edu.uwi.sta.comp3275project.adapters.DBItemAdapter;
import edu.uwi.sta.comp3275project.models.DBHelper;
import edu.uwi.sta.comp3275project.models.RollContract;
import edu.uwi.sta.comp3275project.models.studentProvider;

public class ResultCourse extends AppCompatActivity {
    String[] Columns = new String[]{
            RollContract.RollEntry.STUDENT_ID,RollContract.RollEntry.COURSE_ID,
            RollContract.RollEntry.COURSE,RollContract.RollEntry.TIME, RollContract.RollEntry.ATTENDED

    };
    ListView lv;
    private ArrayAdapter<studentProvider> adapter;
    ArrayList<studentProvider> attendance = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        setTitle("Search Results");
        setUpUI();
        setUpAdapter();
        Bundle bundle = getIntent().getExtras();
        if (bundle.containsKey("course")) {
            final String course = bundle.getString("course");


            (new Thread(new Runnable() {
                    @Override
                    public void run() {
                        // Code to extract information from database
                        final SQLiteDatabase db = (new DBHelper(getApplicationContext())).getReadableDatabase(); // create database object, get database, assign usage to readable to prevent locks and assign it to SQL Database db
                        // the database will execute the query based on options we specify and store in the Cursor
                        Cursor res = db.query(RollContract.RollEntry.TABLE_NAME, Columns, RollContract.RollEntry.COURSE + " LIKE " +"'"+"%"+ course+"%" +"'", null, null, null, null);
                        while (res.moveToNext()) {

                            final String id = res.getString(res.getColumnIndex(RollContract.RollEntry.STUDENT_ID));
                            final String courseId = res.getString(res.getColumnIndex(RollContract.RollEntry.COURSE_ID));
                            final String Course = res.getString(res.getColumnIndex(RollContract.RollEntry.COURSE));
                            final String Time = res.getString(res.getColumnIndex(RollContract.RollEntry.TIME));
                            final String Attended = res.getString(res.getColumnIndex(RollContract.RollEntry.ATTENDED));


                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    // update the UI

                                    studentProvider roll = new studentProvider(id, courseId, Course, Time,Attended);
                                    attendance.add(roll);
                                    lv.post(new Runnable() {
                                        @Override
                                        public void run() {
                                            //Notify the adapter that the list changed listview will be redrawn
                                            adapter.notifyDataSetChanged();

                                        }
                                    });

                                }
                            });
                            db.close();// close the database
                        }
                    }
                })).start();





        }
        else{
            Toast.makeText(this,"No Course was entered",Toast.LENGTH_LONG).show();
        }
    }
    protected void setUpUI(){
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        lv = (ListView)findViewById(R.id.result);

    }
    protected void setUpAdapter(){
        adapter = new DBItemAdapter(this,attendance);
        lv.setAdapter(adapter);
    }
}
